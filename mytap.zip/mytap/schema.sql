-- Start a transaction.
BEGIN;

-- Turn off safe updates.
SET SQL_SAFE_UPDATES=0;

-- Plan the tests.
#SELECT tap.plan(1);

-- Run the tests.
-- The following variable would normally be populated
 -- from the stored proc or function that you’re testing.
SET @testvalue = 'test';
SELECT tap.ok( @testvalue LIKE 'test', '@testvalue compare' );
-- select hasnt_table(database(), '__tcache__', 'I got sometable');
select col_has_type( database(), 'users', 'id', 'bigint(20)', 'type data harus interger');
select * from __cache__;
-- Finish the tests and clean up.
CALL tap.finish();
ROLLBACK;