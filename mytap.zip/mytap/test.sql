 
-- Start a transaction.
BEGIN;

-- Plan the tests.
SELECT tap.plan(1);

-- Run the tests.
SELECT tap.pass( 'My test passed, w00t!' );
SELECT has_table(database(), '__tcache__', 'I got sometable');
select col_has_type( database(), '__tcache__', 'id', 'bigint(11)', 'type data harus interger');
select * from users;

-- Finish the tests and clean up.
CALL tap.finish();
ROLLBACK;